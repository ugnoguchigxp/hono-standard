import { Link, useBlocker, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LockKeyhole } from "lucide-react";
import type { Value } from "platejs";
import { useCallback, useEffect, useRef, useState } from "react";
import type { GetPageResponse } from "@shared/schemas/pages.schema";
import {
	HttpStatusError,
	useCreatePageMutation,
	useMovePageMutation,
	PageParentConflictError,
	InvalidPageHierarchyError,
	usePageQuery,
	usePagesQuery,
	useUpdatePageContentMutation,
	type PageSummary,
} from "../api";
import { useAuth } from "../auth-context";
import { PageTitleEditor } from "../components/page-title-editor";
import { PageEditor } from "../components/page-editor";
import { PageMoveDialog } from "../components/page-move-dialog";
import { PageTree, type PageTreeItem } from "../components/page-tree";
import {
	pageAutosaveStatusLabel,
	usePageAutosave,
	type PageAutosaveStatus,
} from "../hooks/use-page-autosave";
import {
	PageLeaveDialog,
	type PageEditGuardState,
	usePageAutosaveHold,
	usePageEditGuard,
	useSyncPageEditGuard,
} from "../page-edit-guard";

function parentsWithChildren(pages: readonly PageTreeItem[]): Set<string> {
	const ids = new Set(pages.map((page) => page.id));
	const parents = new Set<string>();
	for (const page of pages) {
		if (page.parentId && ids.has(page.parentId)) parents.add(page.parentId);
	}
	return parents;
}

function isNotFound(error: unknown): boolean {
	return error instanceof HttpStatusError && error.status === 404;
}

function PageDocument({
	userId,
	pageId,
	detail,
	pages,
	moveRequest,
	onMoveSuccess,
}: {
	userId: string;
	pageId: string;
	detail: GetPageResponse;
	pages: readonly PageSummary[];
	moveRequest: number;
	onMoveSuccess: (parentId: string | null) => void;
}) {
	const queryClient = useQueryClient();
	const pageQuery = usePageQuery(userId, pageId);
	const mutation = useUpdatePageContentMutation(userId, pageId);
	const moveMutation = useMovePageMutation(userId, pageId);
	const serverValue = detail.content.value as Value;
	const logoutHold = usePageAutosaveHold();
	const [reloadConfirmOpen, setReloadConfirmOpen] = useState(false);
	const [reloadError, setReloadError] = useState<string | null>(null);
	const [moveOpen, setMoveOpen] = useState(false);
	const [moveError, setMoveError] = useState<string | null>(null);
	const [moveExpectedParentId, setMoveExpectedParentId] = useState<
		string | null
	>(detail.page.parentId);
	const [moveTargetParentId, setMoveTargetParentId] = useState<string | null>(
		null,
	);
	const [moveNeedsCheck, setMoveNeedsCheck] = useState(false);
	const [moveChecking, setMoveChecking] = useState(false);
	const moveSendingRef = useRef(false);
	const handledMoveRequest = useRef(moveRequest);
	const reloadRequestRef = useRef(0);
	useEffect(
		() => () => {
			reloadRequestRef.current += 1;
		},
		[],
	);
	const [titleGuard, setTitleGuard] = useState<PageEditGuardState>({
		unsaved: false,
		saving: false,
	});
	const leaveRef = useRef({ unsaved: false, saving: false });
	const shouldBlockFn = useCallback(
		() => leaveRef.current.unsaved || leaveRef.current.saving,
		[],
	);
	const enableBeforeUnload = useCallback(
		() => leaveRef.current.unsaved || leaveRef.current.saving,
		[],
	);
	const blocker = useBlocker({
		shouldBlockFn,
		enableBeforeUnload,
		withResolver: true,
	});
	const bodyStatusRef = useRef<PageAutosaveStatus>("saved");
	const discardHold =
		logoutHold ||
		reloadConfirmOpen ||
		(blocker.status === "blocked" && bodyStatusRef.current !== "saving");
	const autosave = usePageAutosave({
		userId,
		pageId,
		serverValue,
		serverRevision: detail.content.revision,
		hold: discardHold,
		save: async (input) => {
			const body = await mutation.mutateAsync({
				revision: input.revision,
				value: input.value as GetPageResponse["content"]["value"],
			});
			return {
				revision: body.content.revision,
				value: body.content.value as Value,
			};
		},
	});
	const phase = autosave.status;
	bodyStatusRef.current = phase;
	const bodyUnsaved =
		phase === "unsaved" || phase === "failed" || phase === "conflict";
	const unsaved = bodyUnsaved || titleGuard.unsaved;
	const saving =
		phase === "saving" || titleGuard.saving || moveMutation.isPending;
	leaveRef.current = { unsaved, saving };
	useSyncPageEditGuard({ unsaved, saving });
	useEffect(() => {
		if (moveRequest === handledMoveRequest.current) return;
		handledMoveRequest.current = moveRequest;
		if (leaveRef.current.unsaved || leaveRef.current.saving) {
			setMoveError("変更を保存するか取り消してから移動してください");
			return;
		}
		setMoveExpectedParentId(detail.page.parentId);
		setMoveTargetParentId(null);
		setMoveError(null);
		setMoveNeedsCheck(false);
		setMoveOpen(true);
	}, [detail.page.parentId, moveRequest]);
	const blockedDuringSave = useRef(false);
	useEffect(() => {
		if (blocker.status !== "blocked") {
			blockedDuringSave.current = false;
			return;
		}
		if (saving) {
			blockedDuringSave.current = true;
			return;
		}
		if (blockedDuringSave.current) {
			blockedDuringSave.current = false;
			blocker.reset();
		}
	}, [blocker, saving]);

	const reloadServer = async () => {
		const requestId = ++reloadRequestRef.current;
		const result = await pageQuery.refetch();
		// A cancelled request may still finish and update the query cache.
		// Only the active confirmation may replace the local draft or show errors.
		if (requestId !== reloadRequestRef.current) return;
		if (result.isError || !result.data) {
			const message =
				result.error instanceof Error
					? result.error.message
					: "読み込みに失敗しました";
			setReloadError(message);
			return;
		}
		autosave.resetToServer(
			structuredClone(result.data.content.value) as Value,
			result.data.content.revision,
		);
		mutation.reset();
		setReloadError(null);
		setReloadConfirmOpen(false);
	};

	const checkMoveState = async () => {
		setMoveError(null);
		setMoveChecking(true);
		try {
			await queryClient.refetchQueries(
				{ queryKey: ["pages", userId, "list"], type: "active" },
				{ throwOnError: true },
			);
			const result = await pageQuery.refetch({ throwOnError: true });
			if (!result.data) throw new Error("状態を確認できませんでした");
			const latestParentId = result.data.page.parentId;
			setMoveExpectedParentId(latestParentId);
			setMoveNeedsCheck(false);
			setMoveError(
				latestParentId === moveTargetParentId
					? "現在この場所にあります"
					: "最新の場所を確認しました。移動を続ける場合は、もう一度「移動する」を選んでください。",
			);
		} catch (error) {
			setMoveNeedsCheck(true);
			setMoveError(
				error instanceof Error ? error.message : "状態を確認できませんでした",
			);
		} finally {
			setMoveChecking(false);
		}
	};

	const submitMove = async (parentId: string | null) => {
		if (
			leaveRef.current.unsaved ||
			leaveRef.current.saving ||
			moveMutation.isPending ||
			moveSendingRef.current ||
			moveNeedsCheck
		) {
			setMoveError("変更の保存中または未保存の変更があるため移動できません");
			return;
		}
		moveSendingRef.current = true;
		setMoveError(null);
		setMoveTargetParentId(parentId);
		try {
			await moveMutation.mutateAsync({
				parentId,
				expectedParentId: moveExpectedParentId,
			});
			onMoveSuccess(parentId);
			const listState = queryClient.getQueryState(["pages", userId, "list"]);
			const detailState = queryClient.getQueryState([
				"pages",
				userId,
				"detail",
				pageId,
			]);
			setMoveError(
				listState?.status === "error" || detailState?.status === "error"
					? "移動しました。一覧を更新できませんでした。状態を確認してください。"
					: null,
			);
			setMoveExpectedParentId(parentId);
			setMoveNeedsCheck(false);
			setMoveOpen(false);
		} catch (error) {
			setMoveNeedsCheck(true);
			if (error instanceof PageParentConflictError) {
				setMoveError(
					"別の場所でページが移動されています。状態を確認してください。",
				);
			} else if (error instanceof InvalidPageHierarchyError) {
				setMoveError("自分自身や子ページの中には移動できません。");
			} else if (error instanceof HttpStatusError && error.status === 404) {
				setMoveError(
					"ページまたは移動先が見つかりません。状態を確認してください。",
				);
			} else {
				setMoveError(
					"移動結果を確認できませんでした。状態を確認してください。",
				);
			}
		} finally {
			moveSendingRef.current = false;
		}
	};

	return (
		<article className="page-document">
			{moveError && !moveOpen ? (
				<div>
					<p className="pages-error" role="alert">
						{moveError}
					</p>
					<button
						className="auth-open-button"
						onClick={() => void checkMoveState()}
						type="button"
					>
						状態を確認
					</button>
				</div>
			) : null}
			<PageTitleEditor
				userId={userId}
				pageId={pageId}
				title={detail.page.title}
				onGuardChange={setTitleGuard}
				editingDisabled={moveOpen}
			/>
			<PageEditor
				initialValue={autosave.latestValue}
				key={autosave.generation}
				onChange={autosave.onChange}
				pageId={pageId}
				readOnly={moveOpen}
			/>
			<div className="page-save-bar">
				<p className="page-save-status" role="status">
					{pageAutosaveStatusLabel[phase]}
				</p>
				{phase === "conflict" ? (
					<button
						className="auth-open-button"
						onClick={() => {
							setReloadError(null);
							setReloadConfirmOpen(true);
						}}
						type="button"
					>
						サーバー版を読み込み直す
					</button>
				) : (
					<button
						className="auth-open-button"
						disabled={phase !== "unsaved" && phase !== "failed"}
						onClick={() => autosave.saveNow()}
						type="button"
					>
						{phase === "failed" ? "再試行" : "保存"}
					</button>
				)}
			</div>
			{blocker.status === "blocked" && saving ? (
				<p className="page-save-status">保存が終わるまで移動できません</p>
			) : null}
			{blocker.status === "blocked" && !saving ? (
				<PageLeaveDialog
					confirmLabel="破棄して移動"
					onCancel={() => blocker.reset()}
					onConfirm={() => blocker.proceed()}
					title="未保存の変更を破棄して移動しますか"
					titleId="page-nav-leave-title"
				/>
			) : null}
			{reloadConfirmOpen && blocker.status !== "blocked" ? (
				<PageLeaveDialog
					confirmDisabled={pageQuery.isFetching}
					confirmLabel="破棄して読み込み直す"
					message={reloadError}
					onCancel={() => {
						reloadRequestRef.current += 1;
						setReloadError(null);
						setReloadConfirmOpen(false);
					}}
					onConfirm={() => void reloadServer()}
					title="未保存の変更を破棄して、サーバーの本文を読み込み直しますか"
					titleId="page-reload-leave-title"
				/>
			) : null}
			{moveOpen ? (
				<PageMoveDialog
					busy={moveMutation.isPending || moveChecking}
					currentParentId={detail.page.parentId}
					error={moveError}
					onCancel={() => setMoveOpen(false)}
					onCheckState={() => void checkMoveState()}
					onMove={(parentId) => void submitMove(parentId)}
					requiresCheck={moveNeedsCheck}
					pageId={pageId}
					pageTitle={detail.page.title}
					pages={pages}
				/>
			) : null}
		</article>
	);
}

function PageDetail({
	userId,
	pageId,
	pages,
	moveRequest,
	onMoveSuccess,
}: {
	userId: string;
	pageId: string;
	pages: readonly PageSummary[];
	moveRequest: number;
	onMoveSuccess: (parentId: string | null) => void;
}) {
	const pageQuery = usePageQuery(userId, pageId);
	const detail = pageQuery.data;

	if (!detail) {
		if (pageQuery.isError) {
			if (isNotFound(pageQuery.error)) {
				return <p>ページが見つかりません</p>;
			}
			return (
				<div className="pages-status">
					<p className="pages-error">{pageQuery.error.message}</p>
					<button
						type="button"
						className="auth-open-button"
						onClick={() => void pageQuery.refetch()}
					>
						再試行
					</button>
				</div>
			);
		}
		return <p className="muted">読み込み中</p>;
	}

	return (
		<PageDocument
			detail={detail}
			key={`${userId}:${pageId}`}
			moveRequest={moveRequest}
			onMoveSuccess={onMoveSuccess}
			pageId={pageId}
			pages={pages}
			userId={userId}
		/>
	);
}

export function PagesView({ pageId }: { pageId?: string } = {}) {
	const { authUser, authLoading } = useAuth();
	const { saving, unsaved } = usePageEditGuard();
	const navigate = useNavigate();
	const pagesQuery = usePagesQuery(authUser?.id);
	const createMutation = useCreatePageMutation(authUser?.id);
	const [expandedIds, setExpandedIds] = useState<Set<string> | null>(null);
	const [moveRequest, setMoveRequest] = useState(0);
	const pages = pagesQuery.data ?? [];
	const visibleExpanded = expandedIds ?? parentsWithChildren(pages);

	const create = async (parentId: string | null) => {
		if (saving || unsaved) return;
		const page = await createMutation.mutateAsync(parentId).catch(() => null);
		if (!page) return;
		if (parentId) {
			setExpandedIds((current) => {
				const next = new Set(current ?? parentsWithChildren(pages));
				next.add(parentId);
				return next;
			});
		}
		await navigate({
			to: "/pages/$pageId",
			params: { pageId: page.id },
		});
	};

	const toggle = (targetId: string) => {
		setExpandedIds((current) => {
			const next = new Set(current ?? parentsWithChildren(pages));
			if (next.has(targetId)) next.delete(targetId);
			else next.add(targetId);
			return next;
		});
	};

	const expandToParent = (parentId: string | null) => {
		if (!parentId) return;
		const byId = new Map(pages.map((page) => [page.id, page]));
		const ancestors = new Set<string>();
		const visited = new Set<string>();
		let cursor: string | null = parentId;
		while (cursor && !visited.has(cursor)) {
			visited.add(cursor);
			ancestors.add(cursor);
			cursor = byId.get(cursor)?.parentId ?? null;
		}
		setExpandedIds(
			(current) =>
				new Set([...(current ?? parentsWithChildren(pages)), ...ancestors]),
		);
	};

	if (authLoading) {
		return (
			<main className="center-shell">
				<div className="muted">Checking session...</div>
			</main>
		);
	}

	if (!authUser) {
		return (
			<main className="center-shell">
				<section className="signed-in-panel">
					<LockKeyhole className="icon" />
					<h1>Login required</h1>
					<p>This sample route only displays its content after sign-in.</p>
					<Link
						to="/login"
						search={{ redirect: pageId ? `/pages/${pageId}` : "/pages" }}
						className="auth-open-button"
					>
						Login
					</Link>
				</section>
			</main>
		);
	}

	return (
		<main className="pages-shell">
			<aside className="pages-sidebar" aria-label="ページ">
				<button
					type="button"
					className="auth-open-button"
					disabled={createMutation.isPending || saving || unsaved}
					onClick={() => void create(null)}
				>
					新しいページ
				</button>
				{pageId &&
				pagesQuery.isSuccess &&
				pages.some((page) => page.id === pageId) ? (
					<button
						className="auth-open-button"
						disabled={saving || unsaved}
						onClick={() => setMoveRequest((current) => current + 1)}
						type="button"
					>
						ページを移動
					</button>
				) : null}
				{pagesQuery.isPending ? (
					<p className="muted">読み込み中</p>
				) : pagesQuery.isError ? (
					<div className="pages-status">
						<p className="pages-error">{pagesQuery.error.message}</p>
						<button
							type="button"
							className="auth-open-button"
							onClick={() => void pagesQuery.refetch()}
						>
							再試行
						</button>
					</div>
				) : pages.length === 0 ? (
					<p>ページがありません</p>
				) : (
					<PageTree
						pages={pages}
						selectedPageId={pageId}
						expandedIds={visibleExpanded}
						onToggle={toggle}
						onSelect={(nextPageId) => {
							void navigate({
								to: "/pages/$pageId",
								params: { pageId: nextPageId },
							});
						}}
						onCreateChild={(parentId) => {
							void create(parentId);
						}}
						createDisabled={createMutation.isPending || saving || unsaved}
						selectDisabled={saving}
					/>
				)}
				{createMutation.isError ? (
					<p className="pages-error">{createMutation.error.message}</p>
				) : null}
			</aside>
			<section className="pages-main" aria-label="選択中のページ">
				{pageId ? (
					<PageDetail
						userId={authUser.id}
						pageId={pageId}
						pages={pages}
						moveRequest={moveRequest}
						onMoveSuccess={expandToParent}
					/>
				) : (
					<p>ページを選択してください</p>
				)}
			</section>
		</main>
	);
}
