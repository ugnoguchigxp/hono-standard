import { z } from "zod";
import { pageContentValueSchema } from "./page-content.schema";

export const EMPTY_PAGE_VALUE = [
	{ type: "p", children: [{ text: "" }] },
] as const;

export const pageTitleSchema = z.string().trim().min(1).max(200);

export const createPageInputSchema = z.strictObject({
	title: pageTitleSchema,
	parentId: z.union([z.string().uuid(), z.null()]).optional().default(null),
});
export type CreatePageInput = z.infer<typeof createPageInputSchema>;

export const updatePageTitleInputSchema = z.strictObject({
	title: pageTitleSchema,
});
export type UpdatePageTitleInput = z.infer<typeof updatePageTitleInputSchema>;

export const movePageInputSchema = z.strictObject({
	parentId: z.union([z.string().uuid(), z.null()]),
	expectedParentId: z.union([z.string().uuid(), z.null()]),
});
export type MovePageInput = z.infer<typeof movePageInputSchema>;

export const pageParentConflictResponseSchema = z.strictObject({
	message: z.literal("Page parent conflict"),
	code: z.literal("PAGE_PARENT_CONFLICT"),
	currentParentId: z.union([z.string().uuid(), z.null()]),
});
export type PageParentConflictResponse = z.infer<
	typeof pageParentConflictResponseSchema
>;

export const invalidPageHierarchyResponseSchema = z.strictObject({
	message: z.literal("Invalid page hierarchy"),
	code: z.literal("INVALID_PAGE_HIERARCHY"),
});
export type InvalidPageHierarchyResponse = z.infer<
	typeof invalidPageHierarchyResponseSchema
>;

export const pageIdParamSchema = z.object({
	id: z.string().uuid(),
});
export type PageIdParam = z.infer<typeof pageIdParamSchema>;

export const pageSummarySchema = z.object({
	id: z.string().uuid(),
	parentId: z.string().uuid().nullable(),
	title: z.string(),
	createdAt: z.iso.datetime(),
	updatedAt: z.iso.datetime(),
});
export type PageSummary = z.infer<typeof pageSummarySchema>;

export const pageSchema = pageSummarySchema.extend({
	ownerId: z.string().uuid(),
});
export type Page = z.infer<typeof pageSchema>;

export const pageContentSchema = z.object({
	revision: z.number().int().nonnegative(),
	value: pageContentValueSchema,
});
export type PageContent = z.infer<typeof pageContentSchema>;

export const createPageResponseSchema = z.object({
	page: pageSchema,
});
export type CreatePageResponse = z.infer<typeof createPageResponseSchema>;

export const listPagesResponseSchema = z.object({
	pages: z.array(pageSummarySchema),
});
export type ListPagesResponse = z.infer<typeof listPagesResponseSchema>;

export const getPageResponseSchema = z.object({
	page: pageSchema,
	content: pageContentSchema,
});
export type GetPageResponse = z.infer<typeof getPageResponseSchema>;

export const updatePageResponseSchema = z.object({
	page: pageSchema,
});
export type UpdatePageResponse = z.infer<typeof updatePageResponseSchema>;
