import { expect, test, type Page } from "@playwright/test";

async function renameSelectedPage(page: Page, title: string) {
	await page.getByRole("button", { name: "タイトルを編集" }).click();
	await page.getByLabel("ページタイトル").fill(title);
	await page.getByRole("button", { name: "タイトルを保存" }).click();
	await expect(
		page.getByRole("heading", { name: title, exact: true }),
	).toBeVisible();
}

test("moves a page with descendants and keeps its selected URL after reload", async ({
	page,
}) => {
	await page.goto("/login?redirect=%2Fpages");
	await page.getByLabel("Email").fill("admin@example.com");
	await page.getByLabel("Password").fill("password123456");
	await page.getByRole("button", { name: /ログイン/ }).click();
	await expect(page).toHaveURL(/\/pages$/);

	await page.getByRole("button", { name: "新しいページ", exact: true }).click();
	await renameSelectedPage(page, "Move destination");
	await page.getByRole("button", { name: "新しいページ", exact: true }).click();
	await renameSelectedPage(page, "Move source");
	const sourceUrl = page.url();

	await page
		.getByRole("button", { name: "Move sourceの子ページを作成" })
		.click();
	await renameSelectedPage(page, "Move child");
	await page
		.getByRole("button", { name: "Move childの子ページを作成" })
		.click();
	await renameSelectedPage(page, "Move grandchild");
	await page.goto(sourceUrl);

	const movedResponse = page.waitForResponse(
		(response) =>
			response.request().method() === "POST" &&
			response.url().endsWith("/move"),
	);
	await page.getByRole("button", { name: "ページを移動", exact: true }).click();
	const dialog = page.getByRole("dialog", { name: "ページを移動" });
	await expect(dialog.getByLabel("移動先")).toBeFocused();
	await dialog.getByLabel("移動先").selectOption({ label: "Move destination" });
	await dialog.getByRole("button", { name: "移動する" }).click();
	expect((await movedResponse).status()).toBe(200);
	await expect(page).toHaveURL(sourceUrl);
	await expect(
		page.getByRole("heading", { name: "Move source" }),
	).toBeVisible();
	await page.reload();
	await expect(
		page.getByRole("heading", { name: "Move source" }),
	).toBeVisible();

	const destinationRow = page
		.getByRole("button", { name: "Move destination" })
		.locator("xpath=ancestor::li[1]");
	await expect(
		destinationRow.getByRole("button", { name: "Move source", exact: true }),
	).toBeVisible();
	const sourceRow = page
		.getByRole("button", { name: "Move source" })
		.locator("xpath=ancestor::li[1]");
	await expect(
		sourceRow.getByRole("button", { name: "Move child", exact: true }),
	).toBeVisible();
	const childRow = page
		.getByRole("button", { name: "Move child" })
		.locator("xpath=ancestor::li[1]");
	await expect(
		childRow.getByRole("button", { name: "Move grandchild", exact: true }),
	).toBeVisible();
});
