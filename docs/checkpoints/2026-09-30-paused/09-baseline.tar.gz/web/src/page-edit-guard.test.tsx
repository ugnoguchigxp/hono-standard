import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import {
	usePageAutosaveHold,
	usePageEditGuard,
	usePublishPageAutosaveHold,
	useSyncPageEditGuard,
} from "./page-edit-guard";

function GuardReader() {
	usePageEditGuard();
	return null;
}

function GuardWriter() {
	useSyncPageEditGuard({ unsaved: true, saving: false });
	return null;
}

function HoldPublisher() {
	usePublishPageAutosaveHold(true);
	return null;
}

function HoldReader() {
	usePageAutosaveHold();
	return null;
}

describe("page edit guard", () => {
	it("requires the provider before reading or updating leave state", () => {
		expect(() => render(<GuardReader />)).toThrow("PageEditGuard is missing.");
		expect(() => render(<GuardWriter />)).toThrow("PageEditGuard is missing.");
		expect(() => render(<HoldPublisher />)).toThrow(
			"PageEditGuard is missing.",
		);
		expect(() => render(<HoldReader />)).toThrow("PageEditGuard is missing.");
	});
});
