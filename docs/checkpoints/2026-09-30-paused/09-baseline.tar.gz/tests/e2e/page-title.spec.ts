import { expect, test } from "@playwright/test";

test("creates, renames, edits and restores a page with its child", async ({
	page,
}) => {
	await page.goto("/login?redirect=%2Fpages");
	await page.getByLabel("Email").fill("admin@example.com");
	await page.getByLabel("Password").fill("password123456");
	await page.getByRole("button", { name: /ログイン/ }).click();
	await expect(page).toHaveURL(/\/pages$/);
	await page.getByRole("button", { name: "新しいページ", exact: true }).click();
	await expect(
		page.getByRole("heading", { name: "無題", exact: true }),
	).toBeVisible();
	const title = `タイトル検証 ${test.info().project.name}`;
	await page.getByRole("button", { name: "タイトルを編集" }).click();
	await page.getByLabel("ページタイトル").fill(` ${title} `);
	await page.getByRole("button", { name: "タイトルを保存" }).click();
	await expect(
		page.getByRole("heading", { name: title, exact: true }),
	).toBeVisible();
	await expect(
		page.getByRole("button", { name: title, exact: true }),
	).toBeVisible();
	const parentUrl = page.url();
	const bodySaved = page.waitForResponse(
		(response) =>
			response.request().method() === "PUT" &&
			response.url().endsWith("/content"),
	);
	const editor = page.getByRole("textbox", { name: "本文", exact: true });
	await editor.click();
	await editor.pressSequentially("Saved body");
	if (!test.info().project.name.startsWith("mobile")) {
		await page.getByRole("button", { name: "保存", exact: true }).click();
	}
	expect((await bodySaved).status()).toBe(200);
	await expect(page.getByRole("status")).toHaveText("保存済み");
	await page.getByRole("button", { name: `${title}の子ページを作成` }).click();
	await expect(
		page.getByRole("heading", { name: "無題", exact: true }),
	).toBeVisible();
	await page.getByRole("button", { name: "タイトルを編集" }).click();
	await page.getByLabel("ページタイトル").fill(`${title} child`);
	await page.getByRole("button", { name: "タイトルを保存" }).click();
	await expect(
		page.getByRole("heading", { name: `${title} child`, exact: true }),
	).toBeVisible();
	await page.goto(parentUrl);
	await page.reload();
	await expect(
		page.getByRole("heading", { name: title, exact: true }),
	).toBeVisible();
	await expect(
		page.getByRole("textbox", { name: "本文", exact: true }),
	).toHaveText("Saved body");
	await expect(
		page.getByRole("button", { name: `${title} child`, exact: true }),
	).toBeVisible();
	await page.getByRole("button", { name: "タイトルを編集" }).click();
	await page.getByLabel("ページタイトル").fill("通信失敗の下書き");
	await page.route("**/api/pages/*", async (route) => {
		if (route.request().method() === "PATCH") await route.abort();
		else await route.continue();
	});
	await page.getByRole("button", { name: "タイトルを保存" }).click();
	await expect(page.getByRole("alert")).toHaveText(
		"タイトルを保存できませんでした",
	);
	await expect(page.getByLabel("ページタイトル")).toHaveValue(
		"通信失敗の下書き",
	);
	await page.getByRole("button", { name: "キャンセル" }).click();
});
