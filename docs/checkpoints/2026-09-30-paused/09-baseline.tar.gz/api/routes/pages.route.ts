import { zValidator } from "@hono/zod-validator";
import type { Context } from "hono";
import { Hono } from "hono";
import {
	contentRevisionConflictResponseSchema,
	type UpdatePageContentResponse,
	updatePageContentInputSchema,
	updatePageContentResponseSchema,
} from "../../shared/schemas/page-content.schema";
import {
	type CreatePageResponse,
	createPageInputSchema,
	createPageResponseSchema,
	type GetPageResponse,
	getPageResponseSchema,
	type ListPagesResponse,
	listPagesResponseSchema,
	pageIdParamSchema,
	type UpdatePageResponse,
	updatePageResponseSchema,
	updatePageTitleInputSchema,
} from "../../shared/schemas/pages.schema";
import { getAuthContextUser } from "../modules/auth/context";
import {
	ContentRevisionConflictError,
	type PagesService,
} from "../modules/pages/pages.service";

const rejectInvalidRequest = (result: { success: boolean }, c: Context) => {
	if (!result.success) {
		return c.json({ message: "Invalid request" }, 400);
	}
};

type PagesRouteDeps = {
	pagesService: PagesService;
};

export function createPagesRoute(deps: PagesRouteDeps) {
	return new Hono()
		.post(
			"/",
			zValidator("json", createPageInputSchema, rejectInvalidRequest),
			async (c) => {
				const authUser = getAuthContextUser(c);
				const body = c.req.valid("json");
				const page = await deps.pagesService.createPage(authUser.userId, body);
				const response = { page } satisfies CreatePageResponse;
				return c.json(createPageResponseSchema.parse(response), 201);
			},
		)
		.get("/", async (c) => {
			const authUser = getAuthContextUser(c);
			const pages = await deps.pagesService.listPages(authUser.userId);
			const response = { pages } satisfies ListPagesResponse;
			return c.json(listPagesResponseSchema.parse(response));
		})
		.get(
			"/:id",
			zValidator("param", pageIdParamSchema, rejectInvalidRequest),
			async (c) => {
				const authUser = getAuthContextUser(c);
				const { id } = c.req.valid("param");
				const result = await deps.pagesService.getPage(authUser.userId, id);
				const response = result satisfies GetPageResponse;
				return c.json(getPageResponseSchema.parse(response));
			},
		)
		.patch(
			"/:id",
			zValidator("param", pageIdParamSchema, rejectInvalidRequest),
			zValidator("json", updatePageTitleInputSchema, rejectInvalidRequest),
			async (c) => {
				const authUser = getAuthContextUser(c);
				const { id } = c.req.valid("param");
				const { title } = c.req.valid("json");
				const page = await deps.pagesService.renamePage(
					authUser.userId,
					id,
					title,
				);
				const response = { page } satisfies UpdatePageResponse;
				return c.json(updatePageResponseSchema.parse(response));
			},
		)
		.put(
			"/:id/content",
			zValidator("param", pageIdParamSchema, rejectInvalidRequest),
			zValidator("json", updatePageContentInputSchema, rejectInvalidRequest),
			async (c) => {
				const authUser = getAuthContextUser(c);
				const { id } = c.req.valid("param");
				const body = c.req.valid("json");
				try {
					const content = await deps.pagesService.updatePageContent(
						authUser.userId,
						id,
						body,
					);
					const response = updatePageContentResponseSchema.parse({ content });
					return c.json(response satisfies UpdatePageContentResponse);
				} catch (error) {
					if (error instanceof ContentRevisionConflictError) {
						return c.json(
							contentRevisionConflictResponseSchema.parse({
								message: "Content revision conflict",
								currentRevision: error.currentRevision,
							}),
							409,
						);
					}
					throw error;
				}
			},
		);
}
