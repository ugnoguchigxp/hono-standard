import fs from "node:fs/promises";
import { HTTPException } from "hono/http-exception";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { HttpError } from "./http-error";

// Mock environment and DB connection before importing app
vi.mock("../db", () => ({
	createDbRuntime: vi.fn().mockReturnValue({
		checkReady: vi.fn().mockResolvedValue(undefined),
		client: {
			read: {
				query: {
					users: {
						findFirst: vi.fn(),
					},
				},
			},
			write: {
				execute: vi.fn(),
				close: vi.fn(),
			},
		},
		close: vi.fn(),
	}),
}));

vi.mock("./env", () => ({
	readAppEnv: vi.fn().mockReturnValue({
		nodeEnv: "test",
		host: "127.0.0.1",
		port: 5173,
		databaseUrl: "mock.db",
		jwtSecret: "x".repeat(32),
		jwtAccessExpiresIn: "15m",
		jwtRefreshExpiresIn: "7d",
		loginRateLimitMaxAttempts: 5,
		loginRateLimitWindowSeconds: 300,
		appUrl: "http://localhost:5173",
		corsOrigins: ["http://localhost:5173"],
		trustProxy: true,
		secureCookie: false,
		cookieSameSite: "lax",
		securityHeadersMode: "auto",
	}),
}));

// Mock Bun global variable before importing hono/bun dependent code
Object.assign(globalThis, {
	Bun: {
		file: () => ({
			exists: () => Promise.resolve(true),
		}),
	},
});

// Dynamically import app so globalThis.Bun is defined first
const { default: app, createApp, getAppRuntime } = await import("./hono");

// Add test routes before any request is processed (Hono routers lock after first request)
app.post("/api/test-http-error", () => {
	throw new HttpError(400, "Bad Parameters");
});

app.post("/api/test-hono-http-exception", () => {
	throw new HTTPException(403, { message: "Access Forbidden" });
});

app.post("/api/test-generic-error", () => {
	throw new Error("Something blew up");
});

app.post("/api/test-http-error-500", () => {
	throw new HttpError(500, "Persisted write failed");
});

app.post("/api/test-hono-http-exception-500", () => {
	throw new HTTPException(500, { message: "Upstream failed" });
});

describe("hono app entry", () => {
	beforeEach(() => {
		vi.restoreAllMocks();
	});

	it("should return 200 for /api/health", async () => {
		const res = await app.request("/api/health");
		expect(res.status).toBe(200);
		const body = await res.json();
		expect(body.status).toBe("ok");
	});

	it("reports DB readiness while liveness stays independent of DB failure", async () => {
		const runtime = await getAppRuntime();
		expect((await app.request("/api/ready")).status).toBe(200);
		vi.spyOn(runtime.dbRuntime, "checkReady").mockRejectedValueOnce(
			new Error("DB unavailable"),
		);
		expect((await app.request("/api/ready")).status).toBe(503);
		expect((await app.request("/api/health")).status).toBe(200);
	});

	it("should apply security headers to API responses", async () => {
		const res = await app.request("/api/health");

		expect(res.headers.get("Content-Security-Policy")).toContain(
			"default-src 'self'",
		);
		expect(res.headers.get("Content-Security-Policy")).toContain(
			"object-src 'none'",
		);
		expect(res.headers.get("X-Frame-Options")).toBe("SAMEORIGIN");
		expect(res.headers.get("X-Content-Type-Options")).toBe("nosniff");
	});

	it("reuses the initialized runtime", async () => {
		const first = await getAppRuntime();
		const second = await getAppRuntime();
		expect(second).toBe(first);
	});

	it("uses the HTTPS security header profile when configured", async () => {
		const runtime = await getAppRuntime();
		const httpsApp = createApp({
			...runtime,
			env: {
				...runtime.env,
				securityHeadersMode: "https",
				secureCookie: true,
			},
		});

		const res = await httpsApp.request("/api/health");
		expect(res.headers.get("Strict-Transport-Security")).toContain("max-age");
	});

	it("should protect sample protected API routes", async () => {
		const res = await app.request("/api/protected/profile");

		expect(res.status).toBe(401);
		expect(res.headers.get("Content-Security-Policy")).toContain(
			"default-src 'self'",
		);
	});

	it("should protect page API routes", async () => {
		expect((await app.request("/api/pages")).status).toBe(401);
		expect(
			(await app.request("/api/pages/a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1"))
				.status,
		).toBe(401);
	});

	it("applies the admin role middleware in the composed API router", async () => {
		const runtime = await getAppRuntime();
		const { generateAccessToken } = await import(
			"../modules/auth/token.service"
		);
		const token = await generateAccessToken(
			{
				userId: "a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1",
				email: "user@example.com",
				role: "member",
			},
			runtime.env,
		);
		const findUserById = vi.fn().mockResolvedValue({
			id: "a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1",
			email: "user@example.com",
			displayName: "User",
			role: "member",
			isActive: true,
		});
		const composedApp = createApp({
			...runtime,
			authService: { findUserById } as unknown as typeof runtime.authService,
		});
		const request = () =>
			composedApp.request("/api/protected/admin", {
				headers: { Authorization: `Bearer ${token}` },
			});

		expect((await request()).status).toBe(403);
		findUserById.mockResolvedValue({
			id: "a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1",
			email: "user@example.com",
			displayName: "User",
			role: "admin",
			isActive: true,
		});
		expect((await request()).status).toBe(200);
	});

	it("should handle CORS origins", async () => {
		const res = await app.request("/api/health", {
			headers: {
				Origin: "http://localhost:5173",
			},
		});
		expect(res.headers.get("Access-Control-Allow-Origin")).toBe(
			"http://localhost:5173",
		);
		expect(res.headers.get("Access-Control-Allow-Credentials")).toBe("true");

		const resInvalid = await app.request("/api/health", {
			headers: {
				Origin: "http://unauthorized.com",
			},
		});
		expect(resInvalid.headers.get("Access-Control-Allow-Origin")).toBeNull();
	});

	it("should handle not found on api endpoints", async () => {
		const res = await app.request("/api/not-a-valid-route");
		expect(res.status).toBe(404);
	});

	it("should return frontend fallback warning when frontend is not built", async () => {
		// Mock fs.readFile to throw error so frontend build is missing
		vi.spyOn(fs, "readFile").mockRejectedValue(new Error("File not found"));

		const res = await app.request("/some-frontend-path");
		expect(res.status).toBe(404);
		const body = await res.text();
		expect(body).toContain("Frontend is not built");
	});

	it("should return index.html content when frontend is built", async () => {
		// Mock fs.readFile to return fake HTML
		vi.spyOn(fs, "readFile").mockResolvedValue("<html>mock-frontend</html>");

		const res = await app.request("/some-frontend-path");
		expect(res.status).toBe(200);
		expect(res.headers.get("Content-Type")).toContain("text/html");
		expect(res.headers.get("Content-Security-Policy")).toContain(
			"frame-ancestors 'self'",
		);
		const body = await res.text();
		expect(body).toBe("<html>mock-frontend</html>");
	});

	// Error Handler integration tests
	describe("Error Handler", () => {
		it("should handle HttpError and return custom status and message", async () => {
			const consoleError = vi
				.spyOn(console, "error")
				.mockImplementation(() => {});
			const res = await app.request(
				"http://localhost:5173/api/test-http-error",
				{
					method: "POST",
					headers: {
						Origin: "http://localhost:5173",
					},
				},
			);
			expect(res.status).toBe(400);
			const body = await res.json();
			expect(body.message).toBe("Bad Parameters");
			expect(consoleError).not.toHaveBeenCalled();
		});

		it("should handle HTTPException and return custom status and message", async () => {
			const res = await app.request(
				"http://localhost:5173/api/test-hono-http-exception",
				{
					method: "POST",
					headers: {
						Origin: "http://localhost:5173",
					},
				},
			);
			expect(res.status).toBe(403);
			const body = await res.json();
			expect(body.message).toBe("Access Forbidden");
		});

		it("should handle generic errors as 500 Internal Server Error", async () => {
			const res = await app.request(
				"http://localhost:5173/api/test-generic-error",
				{
					method: "POST",
					headers: {
						Origin: "http://localhost:5173",
					},
				},
			);
			expect(res.status).toBe(500);
			const body = await res.json();
			expect(body.message).toBe("Something blew up");
		});

		it("logs HttpError responses with status 500", async () => {
			const consoleError = vi
				.spyOn(console, "error")
				.mockImplementation(() => {});
			const res = await app.request(
				"http://localhost:5173/api/test-http-error-500",
				{
					method: "POST",
					headers: {
						Origin: "http://localhost:5173",
					},
				},
			);
			expect(res.status).toBe(500);
			expect(consoleError).toHaveBeenCalled();
			consoleError.mockRestore();
		});

		it("logs HTTPException responses with status 500", async () => {
			const consoleError = vi
				.spyOn(console, "error")
				.mockImplementation(() => {});
			const res = await app.request(
				"http://localhost:5173/api/test-hono-http-exception-500",
				{
					method: "POST",
					headers: {
						Origin: "http://localhost:5173",
					},
				},
			);
			expect(res.status).toBe(500);
			expect(await res.json()).toEqual({ message: "Upstream failed" });
			expect(consoleError).toHaveBeenCalled();
			consoleError.mockRestore();
		});
	});
});
