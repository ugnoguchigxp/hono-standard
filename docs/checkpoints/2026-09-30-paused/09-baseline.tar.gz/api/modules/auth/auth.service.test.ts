import { scryptSync } from "node:crypto";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { AppEnv } from "../../app/env";
import { HttpError } from "../../app/http-error";
import type { AppDatabase, AppDatabaseClient } from "../../db";
import { createSingleWriterClient } from "../../db/client";
import { AuthService } from "./auth.service";
import { hashPassword, verifyPassword } from "./password";

function createMockDb() {
	return {
		query: {
			users: {
				findFirst: vi.fn(),
			},
			refreshTokens: {
				findFirst: vi.fn(),
			},
		},
		update: vi.fn().mockReturnThis(),
		set: vi.fn().mockReturnThis(),
		where: vi.fn().mockReturnThis(),
		insert: vi.fn().mockReturnThis(),
		values: vi.fn().mockReturnThis(),
		returning: vi.fn(),
		delete: vi.fn().mockReturnThis(),
	};
}

describe("AuthService", () => {
	let mockDb: ReturnType<typeof createMockDb>;
	let mockDatabaseClient: AppDatabaseClient;
	let mockEnv: AppEnv;
	let authService: AuthService;

	const testUserRow = {
		id: "a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1",
		email: "test@example.com",
		passwordHash: "", // Will be filled dynamically in tests
		displayName: "Test User",
		role: "member",
		isActive: true,
		lastLoginAt: null,
		createdAt: new Date(),
		updatedAt: new Date(),
	};

	beforeEach(async () => {
		mockEnv = {
			jwtSecret: "x".repeat(32),
			jwtAccessExpiresIn: "15m",
			jwtRefreshExpiresIn: "7d",
		} as unknown as AppEnv;

		mockDb = createMockDb();

		const database = mockDb as unknown as AppDatabase;
		mockDatabaseClient = {
			read: database,
			write: createSingleWriterClient(database),
		};
		authService = new AuthService(mockDatabaseClient, mockEnv);

		const passwordHash = await hashPassword("password123");
		testUserRow.passwordHash = passwordHash;
	});

	describe("findUserById", () => {
		it("should return mapped user when found", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow);

			const user = await authService.findUserById(testUserRow.id);
			expect(mockDb.query.users.findFirst).toHaveBeenCalledWith(
				expect.objectContaining({
					where: expect.any(Object),
				}),
			);
			expect(user).toBeDefined();
			expect(user?.id).toBe(testUserRow.id);
			expect(user?.role).toBe("member");
		});

		it("should return null when not found", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(null);

			const user = await authService.findUserById("non-existent");
			expect(user).toBeNull();
		});

		it("normalizes unknown stored roles", async () => {
			mockDb.query.users.findFirst.mockResolvedValue({
				...testUserRow,
				role: "legacy-role",
			});

			await expect(
				authService.findUserById(testUserRow.id),
			).resolves.toMatchObject({
				role: "member",
			});
		});
	});

	describe("findUserByEmail", () => {
		it("should query user by lowercase email", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow);

			const user = await authService.findUserByEmail("TEST@example.com");
			expect(user).toBeDefined();
			expect(user?.email).toBe(testUserRow.email);
		});
	});

	describe("login", () => {
		it("upgrades a legacy password only after successful authentication", async () => {
			const salt = "12".repeat(16);
			const legacyHash = `s1$${salt}$${scryptSync("password123", salt, 64, { N: 16384, r: 8, p: 1 }).toString("hex")}`;
			mockDb.query.users.findFirst.mockResolvedValue({
				...testUserRow,
				passwordHash: legacyHash,
			});
			await expect(
				authService.login({ email: testUserRow.email, password: "wrong" }),
			).rejects.toThrow("Invalid email or password.");
			expect(mockDb.update).not.toHaveBeenCalled();
			await authService.login({
				email: testUserRow.email,
				password: "password123",
			});
			const updated = mockDb.set.mock.calls[0]?.[0] as { passwordHash: string };
			expect(updated.passwordHash).toMatch(/^s2\$/);
			expect(await verifyPassword("password123", updated.passwordHash)).toBe(
				true,
			);
		});
		it("should login successfully and return tokens", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow);

			// Mock db.update for lastLoginAt
			mockDb.returning.mockResolvedValue(undefined);

			// mock generateRefreshToken (db.insert)
			mockDb.insert.mockReturnThis();
			mockDb.values.mockResolvedValue(undefined);

			const result = await authService.login({
				email: testUserRow.email,
				password: "password123",
			});

			expect(result.accessToken).toBeDefined();
			expect(result.refreshToken).toBeDefined();
			expect(result.user.email).toBe(testUserRow.email);
			expect(mockDb.update).toHaveBeenCalled();
		});

		it("should throw HttpError 401 for invalid credentials", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow);

			await expect(
				authService.login({
					email: testUserRow.email,
					password: "wrong-password",
				}),
			).rejects.toThrowError(new HttpError(401, "Invalid email or password."));
		});

		it("should throw HttpError 401 when user is inactive", async () => {
			const inactiveUser = { ...testUserRow, isActive: false };
			mockDb.query.users.findFirst.mockResolvedValue(inactiveUser);

			await expect(
				authService.login({
					email: testUserRow.email,
					password: "password123",
				}),
			).rejects.toThrowError(new HttpError(401, "Invalid email or password."));
		});

		it("should throw HttpError 404 if user cannot be retrieved after update", async () => {
			// First call for findUserByEmail returns user, second call for findUserById returns null
			mockDb.query.users.findFirst
				.mockResolvedValueOnce(testUserRow)
				.mockResolvedValueOnce(null);

			await expect(
				authService.login({
					email: testUserRow.email,
					password: "password123",
				}),
			).rejects.toThrowError(new HttpError(404, "User not found."));
		});
	});

	describe("refresh", () => {
		it("should refresh tokens using valid refresh token", async () => {
			// First we need a real refresh token
			// We can generate one using token.service or we can just mock consumeRefreshToken.
			// Let's import token.service and mock the db response so we can call authService.refresh.
			const mockInsertDb = {
				query: { refreshTokens: { findFirst: vi.fn() } },
				delete: vi.fn().mockReturnThis(),
				where: vi.fn().mockResolvedValue(undefined),
				insert: vi.fn().mockReturnThis(),
				values: vi.fn().mockResolvedValue(undefined),
			};

			const { generateRefreshToken } = await import("./token.service");
			const token = await generateRefreshToken(
				{
					userId: testUserRow.id,
					email: testUserRow.email,
					role: "member",
				},
				createSingleWriterClient(mockInsertDb as unknown as AppDatabase),
				mockEnv,
			);

			mockDb.query.refreshTokens.findFirst
				.mockResolvedValueOnce({
					id: "refresh-row-id",
					userId: testUserRow.id,
					familyId: null,
					consumedAt: null,
					revokedAt: null,
					expiresAt: new Date(Date.now() + 60 * 60 * 1000),
				})
				.mockResolvedValueOnce(undefined);

			// Mock findUserById
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow);

			const result = await authService.refresh(token);
			expect(result.accessToken).toBeDefined();
			expect(result.refreshToken).toBeDefined();
		});

		it("should throw HttpError 401 when refreshed user is inactive", async () => {
			const { generateRefreshToken } = await import("./token.service");
			const token = await generateRefreshToken(
				{
					userId: testUserRow.id,
					email: testUserRow.email,
					role: "member",
				},
				createSingleWriterClient({
					query: { refreshTokens: { findFirst: vi.fn() } },
					delete: vi.fn().mockReturnThis(),
					where: vi.fn().mockResolvedValue(undefined),
					insert: vi.fn().mockReturnThis(),
					values: vi.fn().mockResolvedValue(undefined),
				} as unknown as AppDatabase),
				mockEnv,
			);

			mockDb.query.refreshTokens.findFirst.mockResolvedValue({
				id: "refresh-row-id",
				userId: testUserRow.id,
				familyId: null,
				consumedAt: null,
				revokedAt: null,
				expiresAt: new Date(Date.now() + 60 * 60 * 1000),
			});

			// Inactive user
			const inactiveUser = { ...testUserRow, isActive: false };
			mockDb.query.users.findFirst.mockResolvedValue(inactiveUser);

			await expect(authService.refresh(token)).rejects.toThrowError(
				new HttpError(401, "User account is inactive or deleted."),
			);
		});
	});

	describe("logout", () => {
		it("should revoke refresh token if provided", async () => {
			mockDb.query.refreshTokens.findFirst.mockResolvedValue({
				id: "refresh-row-id",
				familyId: "a2a2a2a2-a2a2-42a2-a2a2-a2a2a2a2a2a2",
			});
			await authService.logout("refresh-token");
			expect(mockDb.update).toHaveBeenCalled();
		});

		it("should do nothing when token is not provided", async () => {
			await authService.logout(undefined);
			expect(mockDb.query.refreshTokens.findFirst).not.toHaveBeenCalled();
		});
	});

	describe("createAdmin", () => {
		it("should create new admin user successfully", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(null); // No existing email

			const newAdminRow = {
				...testUserRow,
				email: "admin@example.com",
				role: "admin",
			};
			mockDb.returning.mockResolvedValue([newAdminRow]);

			const admin = await authService.createAdmin({
				email: "admin@example.com",
				displayName: "Admin",
				password: "password123456",
			});

			expect(admin.email).toBe("admin@example.com");
			expect(admin.role).toBe("admin");
			expect(mockDb.insert).toHaveBeenCalled();
		});

		it("should throw HttpError 409 when email is already in use", async () => {
			mockDb.query.users.findFirst.mockResolvedValue(testUserRow); // Email already in use

			await expect(
				authService.createAdmin({
					email: testUserRow.email,
					displayName: "Admin",
					password: "password123456",
				}),
			).rejects.toThrowError(new HttpError(409, "Email already in use."));
		});
	});
});
