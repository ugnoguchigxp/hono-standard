import { describe, expect, it } from "vitest";
import type { UpdatePageContentInput } from "../../../shared/schemas/page-content.schema";
import { EMPTY_PAGE_VALUE } from "../../../shared/schemas/pages.schema";
import { HttpError } from "../../app/http-error";
import type { AppDatabase, AppDatabaseClient } from "../../db";
import { pageContents, pages } from "../../db/schema";
import {
	ContentRevisionConflictError,
	createPagesService,
} from "./pages.service";

const input: UpdatePageContentInput = {
	revision: 0,
	value: [{ type: "p", children: [{ text: "hello" }] }],
};

function createService(options: {
	page?: { id: string; updatedAt?: Date };
	content?: { revision: number };
	updated?: Array<{ revision: number; valueJson: string } | undefined>;
}) {
	const tx = {
		select() {
			return {
				from(table: unknown) {
					return {
						where() {
							return {
								get() {
									if (table === pages) {
										return options.page
											? { updatedAt: new Date(0), ...options.page }
											: undefined;
									}
									if (table === pageContents) return options.content;
									throw new Error(`unexpected table: ${String(table)}`);
								},
							};
						},
					};
				},
			};
		},
		update(table: unknown) {
			return {
				set() {
					return {
						where() {
							return {
								returning() {
									return {
										get() {
											return table === pages ? { id: "page-1" } : undefined;
										},
										all() {
											return table === pageContents
												? (options.updated ?? [])
												: [];
										},
									};
								},
							};
						},
					};
				},
			};
		},
	};
	const client = {
		read: {},
		write: {
			execute: async <TResult>(operation: (database: AppDatabase) => TResult) =>
				operation({
					transaction: (fn: (transaction: typeof tx) => TResult) => fn(tx),
				} as unknown as AppDatabase),
			close: async () => undefined,
		},
	} as unknown as AppDatabaseClient;
	return createPagesService(client);
}

const now = new Date("2026-09-30T00:00:00.000Z");

function pageRow(
	overrides: Partial<{
		id: string;
		ownerId: string;
		parentId: string | null;
		title: string;
	}> = {},
) {
	return {
		id: "page-1",
		ownerId: "owner-1",
		parentId: null,
		title: "無題",
		createdAt: now,
		updatedAt: now,
		deletedAt: null,
		...overrides,
	};
}

function createPageService(options: {
	parent?: { id: string };
	inserted?: ReturnType<typeof pageRow>;
	pages?: ReturnType<typeof pageRow>[];
	content?: { revision: number; valueJson: string };
	renamed?: ReturnType<typeof pageRow>;
}) {
	const client = {
		read: {
			query: {
				pages: {
					findMany: () => options.pages ?? [],
					findFirst: () => options.pages?.[0],
				},
				pageContents: {
					findFirst: () => options.content,
				},
			},
		},
		write: {
			execute: async <TResult>(operation: (database: AppDatabase) => TResult) =>
				operation({
					transaction(fn: (transaction: unknown) => TResult) {
						const tx = {
							select() {
								return {
									from() {
										return {
											where() {
												return { get: () => options.parent };
											},
										};
									},
								};
							},
							insert(table: unknown) {
								return {
									values() {
										return {
											returning() {
												return {
													get: () =>
														table === pages ? options.inserted : undefined,
												};
											},
											run() {
												return undefined;
											},
										};
									},
								};
							},
						};
						return fn(tx);
					},
					update() {
						return {
							set() {
								return {
									where() {
										return {
											returning() {
												return { get: () => options.renamed };
											},
										};
									},
								};
							},
						};
					},
				} as unknown as AppDatabase),
			close: async () => undefined,
		},
	} as unknown as AppDatabaseClient;
	return createPagesService(client);
}

describe("page ownership operations", () => {
	it("creates, lists, reads, and renames an owned page", async () => {
		const created = pageRow();
		const service = createPageService({
			parent: { id: "page-1" },
			inserted: created,
			pages: [
				created,
				pageRow({ id: "page-2", parentId: "page-1", title: "子" }),
			],
			content: { revision: 0, valueJson: JSON.stringify(EMPTY_PAGE_VALUE) },
			renamed: pageRow({ title: "新しいタイトル" }),
		});

		await expect(
			service.createPage("owner-1", { title: "無題", parentId: null }),
		).resolves.toMatchObject({ id: "page-1", parentId: null, title: "無題" });
		const child = createPageService({
			parent: { id: "page-1" },
			inserted: pageRow({ id: "page-2", parentId: "page-1", title: "子" }),
		});
		await expect(
			child.createPage("owner-1", { title: "子", parentId: "page-1" }),
		).resolves.toMatchObject({
			id: "page-2",
			parentId: "page-1",
			title: "子",
		});
		await expect(service.listPages("owner-1")).resolves.toEqual([
			expect.objectContaining({ id: "page-1", title: "無題" }),
			expect.objectContaining({
				id: "page-2",
				parentId: "page-1",
				title: "子",
			}),
		]);
		await expect(service.getPage("owner-1", "page-1")).resolves.toEqual({
			page: expect.objectContaining({ id: "page-1" }),
			content: { revision: 0, value: EMPTY_PAGE_VALUE },
		});
		await expect(
			service.renamePage("owner-1", "page-1", "新しいタイトル"),
		).resolves.toMatchObject({ title: "新しいタイトル" });
	});

	it("rejects missing parents, pages, content, and failed inserts", async () => {
		const missingParent = createPageService({});
		await expect(
			missingParent.createPage("owner-1", {
				title: "子",
				parentId: "missing",
			}),
		).rejects.toMatchObject({ status: 404, message: "Not found" });

		const failedInsert = createPageService({ parent: { id: "page-1" } });
		await expect(
			failedInsert.createPage("owner-1", {
				title: "子",
				parentId: "page-1",
			}),
		).rejects.toMatchObject({ status: 500 });

		const missingPage = createPageService({ pages: [] });
		await expect(
			missingPage.getPage("owner-1", "missing"),
		).rejects.toMatchObject({ status: 404, message: "Not found" });
		await expect(
			missingPage.renamePage("owner-1", "missing", "新しいタイトル"),
		).rejects.toMatchObject({ status: 404 });

		const missingContent = createPageService({ pages: [pageRow()] });
		await expect(
			missingContent.getPage("owner-1", "page-1"),
		).rejects.toMatchObject({ status: 500 });

		const brokenContent = createPageService({
			pages: [pageRow()],
			content: { revision: 0, valueJson: "not-json" },
		});
		await expect(
			brokenContent.getPage("owner-1", "page-1"),
		).rejects.toMatchObject({ status: 500 });

		const emptyArrayContent = createPageService({
			pages: [pageRow()],
			content: { revision: 0, valueJson: "[]" },
		});
		await expect(
			emptyArrayContent.getPage("owner-1", "page-1"),
		).rejects.toMatchObject({ status: 500 });
	});
});

describe("updatePageContent", () => {
	it("returns the saved revision and value", async () => {
		const service = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [
				{
					revision: 1,
					valueJson: JSON.stringify(input.value),
				},
			],
		});

		await expect(
			service.updatePageContent("owner-1", "page-1", input),
		).resolves.toEqual({
			revision: 1,
			value: input.value,
		});
	});

	it("rejects missing, conflicting, and failed content updates", async () => {
		const missingPage = createService({});
		await expect(
			missingPage.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 404, message: "Not found" });

		const missingContent = createService({ page: { id: "page-1" } });
		await expect(
			missingContent.updatePageContent("owner-1", "page-1", input),
		).rejects.toBeInstanceOf(HttpError);

		const conflict = createService({
			page: { id: "page-1" },
			content: { revision: 2 },
		});
		await expect(
			conflict.updatePageContent("owner-1", "page-1", input),
		).rejects.toBeInstanceOf(ContentRevisionConflictError);

		const emptyUpdate = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [],
		});
		await expect(
			emptyUpdate.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 500 });

		const blankRow = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [undefined],
		});
		await expect(
			blankRow.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 500 });

		const staleRevision = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [{ revision: 4, valueJson: JSON.stringify(input.value) }],
		});
		await expect(
			staleRevision.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 500 });

		const invalidJson = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [{ revision: 1, valueJson: "not-json" }],
		});
		await expect(
			invalidJson.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 500 });

		const notAnArray = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [{ revision: 1, valueJson: JSON.stringify({ text: "nope" }) }],
		});
		await expect(
			notAnArray.updatePageContent("owner-1", "page-1", input),
		).rejects.toBeInstanceOf(HttpError);

		const invalidShape = createService({
			page: { id: "page-1" },
			content: { revision: 0 },
			updated: [{ revision: 1, valueJson: "[]" }],
		});
		await expect(
			invalidShape.updatePageContent("owner-1", "page-1", input),
		).rejects.toMatchObject({ status: 500 });
	});
});
