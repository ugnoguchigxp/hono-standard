import { and, asc, eq, isNull } from "drizzle-orm";
import {
	type PageContentValue,
	pageContentValueSchema,
	type SavedPageContent,
	savedPageContentSchema,
	type UpdatePageContentInput,
} from "../../../shared/schemas/page-content.schema";
import {
	type CreatePageInput,
	EMPTY_PAGE_VALUE,
	type Page,
	type PageContent,
	type PageSummary,
} from "../../../shared/schemas/pages.schema";
import { HttpError } from "../../app/http-error";
import type { AppDatabase, AppDatabaseClient } from "../../db";
import { pageContents, pages } from "../../db/schema";

const notFound = () => new HttpError(404, "Not found");
const internalError = () => new HttpError(500, "Internal server error");

export class ContentRevisionConflictError extends Error {
	readonly currentRevision: number;

	constructor(currentRevision: number) {
		super("Content revision conflict");
		this.name = "ContentRevisionConflictError";
		this.currentRevision = currentRevision;
	}
}

const toIsoString = (value: Date): string => value.toISOString();

const toPage = (row: typeof pages.$inferSelect): Page => ({
	id: row.id,
	ownerId: row.ownerId,
	parentId: row.parentId ?? null,
	title: row.title,
	createdAt: toIsoString(row.createdAt),
	updatedAt: toIsoString(row.updatedAt),
});

const toPageSummary = (row: typeof pages.$inferSelect): PageSummary => {
	const page = toPage(row);
	return {
		id: page.id,
		parentId: page.parentId,
		title: page.title,
		createdAt: page.createdAt,
		updatedAt: page.updatedAt,
	};
};

const parseStoredPageValue = (valueJson: string): PageContentValue => {
	try {
		const parsed: unknown = JSON.parse(valueJson);
		return pageContentValueSchema.parse(parsed);
	} catch (error) {
		if (error instanceof HttpError) {
			throw error;
		}
		throw internalError();
	}
};

const ownedPageCondition = (ownerId: string, pageId: string) =>
	and(
		eq(pages.id, pageId),
		eq(pages.ownerId, ownerId),
		isNull(pages.deletedAt),
	);

export function createPagesService(client: AppDatabaseClient) {
	return {
		async createPage(ownerId: string, input: CreatePageInput): Promise<Page> {
			const parentId = input.parentId;
			const now = new Date();
			const created = await client.write.execute((db: AppDatabase) =>
				db.transaction((tx) => {
					if (parentId) {
						const parent = tx
							.select({ id: pages.id })
							.from(pages)
							.where(ownedPageCondition(ownerId, parentId))
							.get();
						if (!parent) {
							throw notFound();
						}
					}
					const inserted = tx
						.insert(pages)
						.values({
							ownerId,
							parentId,
							title: input.title,
							createdAt: now,
							updatedAt: now,
						})
						.returning()
						.get();
					if (!inserted) {
						throw internalError();
					}
					tx.insert(pageContents)
						.values({
							pageId: inserted.id,
							valueJson: JSON.stringify(EMPTY_PAGE_VALUE),
							revision: 0,
							updatedAt: now,
						})
						.run();
					return inserted;
				}),
			);
			return toPage(created);
		},

		async listPages(ownerId: string): Promise<PageSummary[]> {
			const rows = await client.read.query.pages.findMany({
				where: and(eq(pages.ownerId, ownerId), isNull(pages.deletedAt)),
				orderBy: [asc(pages.createdAt), asc(pages.id)],
			});
			return rows.map(toPageSummary);
		},

		async getPage(
			ownerId: string,
			pageId: string,
		): Promise<{ page: Page; content: PageContent }> {
			const page = await client.read.query.pages.findFirst({
				where: ownedPageCondition(ownerId, pageId),
			});
			if (!page) {
				throw notFound();
			}
			const content = await client.read.query.pageContents.findFirst({
				where: eq(pageContents.pageId, pageId),
			});
			if (!content) {
				throw internalError();
			}
			return {
				page: toPage(page),
				content: {
					revision: content.revision,
					value: parseStoredPageValue(content.valueJson),
				},
			};
		},

		async renamePage(
			ownerId: string,
			pageId: string,
			title: string,
		): Promise<Page> {
			const now = new Date();
			const updated = await client.write.execute((db: AppDatabase) =>
				db
					.update(pages)
					.set({ title, updatedAt: now })
					.where(ownedPageCondition(ownerId, pageId))
					.returning()
					.get(),
			);
			if (!updated) {
				throw notFound();
			}
			return toPage(updated);
		},

		async updatePageContent(
			ownerId: string,
			pageId: string,
			input: UpdatePageContentInput,
		): Promise<SavedPageContent> {
			const valueJson = JSON.stringify(input.value);
			return client.write.execute((db: AppDatabase) =>
				db.transaction((tx) => {
					const page = tx
						.select({ id: pages.id, updatedAt: pages.updatedAt })
						.from(pages)
						.where(ownedPageCondition(ownerId, pageId))
						.get();
					if (!page) {
						throw notFound();
					}
					const now = new Date(
						Math.max(Date.now(), page.updatedAt.getTime() + 1000),
					);
					const current = tx
						.select({ revision: pageContents.revision })
						.from(pageContents)
						.where(eq(pageContents.pageId, pageId))
						.get();
					if (!current) {
						throw internalError();
					}
					if (current.revision !== input.revision) {
						throw new ContentRevisionConflictError(current.revision);
					}
					const updated = tx
						.update(pageContents)
						.set({
							valueJson,
							revision: input.revision + 1,
							updatedAt: now,
						})
						.where(
							and(
								eq(pageContents.pageId, pageId),
								eq(pageContents.revision, input.revision),
							),
						)
						.returning({
							revision: pageContents.revision,
							valueJson: pageContents.valueJson,
						})
						.all();
					if (updated.length !== 1 || !updated[0]) {
						throw internalError();
					}
					if (updated[0].revision !== input.revision + 1) {
						throw internalError();
					}
					const updatedPage = tx
						.update(pages)
						.set({ updatedAt: now })
						.where(ownedPageCondition(ownerId, pageId))
						.returning({ id: pages.id })
						.get();
					if (!updatedPage) {
						throw internalError();
					}
					try {
						return savedPageContentSchema.parse({
							revision: updated[0].revision,
							value: parseStoredPageValue(updated[0].valueJson),
						});
					} catch (error) {
						if (error instanceof HttpError) {
							throw error;
						}
						throw internalError();
					}
				}),
			);
		},
	};
}

export type PagesService = ReturnType<typeof createPagesService>;
