import { beforeEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
	setQueryData: vi.fn(),
	cancelQueries: vi.fn().mockResolvedValue(undefined),
	removeQueries: vi.fn(),
	useMutation: vi.fn((options) => options),
	useQuery: vi.fn((options) => options),
	useQueryClient: vi.fn(),
}));

vi.mock("@tanstack/react-query", () => ({
	useMutation: mocks.useMutation,
	useQuery: mocks.useQuery,
	useQueryClient: mocks.useQueryClient,
}));

import {
	authMeQueryKey,
	fetchMe,
	fetchProtectedProfile,
	protectedProfileQueryKey,
	useCurrentUserQuery,
	useLoginMutation,
	useLogoutMutation,
	useProtectedProfileQuery,
	useDuplicatePageMutation,
	setSessionUser,
	useUpdatePageContentMutation,
} from "./api";

beforeEach(() => {
	vi.clearAllMocks();
	mocks.useQueryClient.mockReturnValue({
		setQueryData: mocks.setQueryData,
		cancelQueries: mocks.cancelQueries,
		removeQueries: mocks.removeQueries,
	});
});

describe("web API hooks", () => {
	it("configures current-user and protected-profile queries", () => {
		useCurrentUserQuery(false);
		useProtectedProfileQuery("user-id");

		expect(mocks.useQuery).toHaveBeenNthCalledWith(1, {
			queryKey: authMeQueryKey,
			queryFn: fetchMe,
			enabled: false,
		});
		expect(mocks.useQuery).toHaveBeenNthCalledWith(2, {
			queryKey: [...protectedProfileQueryKey, "user-id"],
			queryFn: fetchProtectedProfile,
			enabled: true,
		});
	});

	it("updates the current-user cache before the login callback", async () => {
		const onSuccess = vi.fn();
		const response = {
			user: {
				id: "a1a1a1a1-a1a1-41a1-a1a1-a1a1a1a1a1a1",
				email: "test@example.com",
				displayName: "Test User",
				role: "member",
			},
		};
		const variables = {
			email: response.user.email,
			password: "password123456",
		};

		useLoginMutation({ onSuccess });
		const options = mocks.useMutation.mock.calls[0]?.[0];
		await options.onSuccess(response, variables, undefined, {});

		expect(mocks.setQueryData).toHaveBeenCalledWith(
			authMeQueryKey,
			response.user,
		);
		expect(onSuccess).toHaveBeenCalledWith(response, variables, undefined, {});
	});

	it("clears the current-user cache before the logout callback", async () => {
		const onSuccess = vi.fn();

		useLogoutMutation({ onSuccess });
		const options = mocks.useMutation.mock.calls[0]?.[0];
		await options.onSuccess(undefined, undefined, undefined, {});

		expect(mocks.setQueryData).toHaveBeenCalledWith(authMeQueryKey, null);
		expect(onSuccess).toHaveBeenCalledWith(undefined, undefined, undefined, {});
	});

	it("writes only the confirmed save response into the page detail cache", () => {
		useUpdatePageContentMutation("user-1", "page-1");
		const options = mocks.useMutation.mock.calls.at(-1)?.[0] as {
			networkMode: string;
			onSuccess: (
				body: {
					content: { revision: number; value: unknown };
				},
				input?: unknown,
				epoch?: number,
			) => void;
		};
		expect(options.networkMode).toBe("always");
		const current = {
			page: {
				id: "page-1",
				ownerId: "user-1",
				parentId: null,
				title: "A",
				createdAt: "2026-09-30T00:00:00.000Z",
				updatedAt: "2026-09-30T00:00:00.000Z",
			},
			content: {
				revision: 0,
				value: [{ type: "p", children: [{ text: "draft" }] }],
			},
		};
		const saved = {
			revision: 1,
			value: [{ type: "p", children: [{ text: "saved" }] }],
		};

		options.onSuccess({ content: saved });

		expect(mocks.setQueryData).toHaveBeenCalledWith(
			["pages", "user-1", "detail", "page-1"],
			expect.any(Function),
		);
		const updater = mocks.setQueryData.mock.calls[0]?.[1] as (
			value: typeof current | undefined,
		) => unknown;
		expect(updater(current)).toEqual({ ...current, content: saved });
		expect(updater(undefined)).toBeUndefined();
		const newer = {
			...current,
			content: {
				revision: 3,
				value: [{ type: "p", children: [{ text: "newer" }] }],
			},
		};
		expect(updater(newer)).toBe(newer);

		mocks.setQueryData.mockClear();
		options.onSuccess({ content: saved }, undefined, 1);
		expect(mocks.setQueryData).not.toHaveBeenCalled();
	});

	it("does not invalidate the new session list after an old duplicate response", async () => {
		const queryClient = {
			setQueryData: mocks.setQueryData,
			cancelQueries: mocks.cancelQueries,
			removeQueries: mocks.removeQueries,
			invalidateQueries: vi.fn().mockResolvedValue(undefined),
		};
		mocks.useQueryClient.mockReturnValue(queryClient);
		useDuplicatePageMutation("old-user");
		const options = mocks.useMutation.mock.calls.at(-1)?.[0] as {
			retry: boolean;
			onMutate: () => number;
			onSuccess: (
				body: unknown,
				variables: unknown,
				epoch: number,
			) => Promise<void>;
		};
		expect(options.retry).toBe(false);
		const epoch = options.onMutate();
		await setSessionUser(queryClient as never, {
			id: "new-user",
			email: "new@example.com",
			displayName: "New",
			role: "member",
		});
		await options.onSuccess({ page: { id: "created" } }, {}, epoch);
		expect(queryClient.invalidateQueries).not.toHaveBeenCalled();
	});
});
