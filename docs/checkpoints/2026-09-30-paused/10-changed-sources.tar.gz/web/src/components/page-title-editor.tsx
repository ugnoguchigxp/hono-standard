import { pageTitleSchema } from "../../../shared/schemas/pages.schema";
import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { HttpStatusError, useUpdatePageTitleMutation } from "../api";
import type { PageEditGuardState } from "../page-edit-guard";

export function PageTitleEditor({
	userId,
	pageId,
	title,
	onGuardChange,
	disabled = false,
}: {
	userId: string;
	pageId: string;
	title: string;
	onGuardChange: (state: PageEditGuardState) => void;
	disabled?: boolean;
}) {
	const mutation = useUpdatePageTitleMutation(userId, pageId);
	const [editing, setEditing] = useState(false);
	const [draft, setDraft] = useState(title);
	const [validationError, setValidationError] = useState<string | null>(null);
	const composing = useRef(false);
	const sending = useRef(false);
	const mounted = useRef(true);
	useEffect(() => {
		mounted.current = true;
		return () => {
			mounted.current = false;
		};
	}, []);
	const parsed = pageTitleSchema.safeParse(draft);
	const unsaved = editing && (!parsed.success || parsed.data !== title);
	const saving = mutation.isPending;
	useLayoutEffect(() => {
		onGuardChange({ unsaved, saving });
	}, [unsaved, saving, onGuardChange]);
	const cancel = () => {
		if (sending.current) return;
		setEditing(false);
		setDraft(title);
		setValidationError(null);
		mutation.reset();
	};
	const save = async () => {
		if (sending.current || composing.current) return;
		const input = pageTitleSchema.safeParse(draft);
		if (!input.success) {
			setValidationError("タイトルは空白を除いて1〜200文字で入力してください");
			return;
		}
		if (input.data === title) {
			cancel();
			return;
		}
		setValidationError(null);
		sending.current = true;
		try {
			await mutation.mutateAsync({ title: input.data });
			if (mounted.current) setEditing(false);
		} catch {
			// Keep the draft; retry is explicitly requested by the user.
		} finally {
			sending.current = false;
		}
	};
	if (!editing)
		return (
			<div className="page-title-editor">
				<h1>{title}</h1>
				<button
					className="auth-open-button"
					type="button"
					disabled={disabled}
					onClick={() => {
						setDraft(title);
						mutation.reset();
						setValidationError(null);
						setEditing(true);
					}}
				>
					タイトルを編集
				</button>
			</div>
		);
	const error =
		validationError ??
		(mutation.isError
			? mutation.error instanceof HttpStatusError &&
				mutation.error.status === 404
				? "ページが見つかりません"
				: "タイトルを保存できませんでした"
			: null);
	return (
		<div className="page-title-editor">
			<label htmlFor="page-title-input">ページタイトル</label>
			<input
				id="page-title-input"
				className="page-title-input"
				value={draft}
				disabled={saving || disabled}
				aria-invalid={Boolean(error)}
				aria-describedby={error ? "page-title-error" : undefined}
				onChange={(event) => {
					setDraft(event.target.value);
					setValidationError(null);
				}}
				onCompositionStart={() => {
					composing.current = true;
				}}
				onCompositionEnd={() => {
					composing.current = false;
				}}
				onKeyDown={(event) => {
					if (
						composing.current ||
						event.nativeEvent.isComposing ||
						event.keyCode === 229
					)
						return;
					if (event.key === "Enter") {
						event.preventDefault();
						void save();
					}
					if (event.key === "Escape") {
						event.preventDefault();
						cancel();
					}
				}}
			/>
			<div className="page-save-bar">
				<button
					className="auth-open-button"
					type="button"
					disabled={saving || disabled}
					onClick={() => void save()}
				>
					{mutation.isError ? "再試行" : "タイトルを保存"}
				</button>
				<button
					className="auth-open-button"
					type="button"
					disabled={saving || disabled}
					onClick={cancel}
				>
					キャンセル
				</button>
				<p role="status">
					{saving
						? "タイトル保存中"
						: unsaved
							? "タイトル未保存"
							: "タイトル保存済み"}
				</p>
			</div>
			{error ? (
				<p id="page-title-error" className="pages-error" role="alert">
					{error}
				</p>
			) : null}
		</div>
	);
}
