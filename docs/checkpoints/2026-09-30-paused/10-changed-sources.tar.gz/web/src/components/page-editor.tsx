import {
	BoldPlugin,
	H1Plugin,
	H2Plugin,
	ItalicPlugin,
} from "@platejs/basic-nodes/react";
import type { Value } from "platejs";
import {
	ParagraphPlugin,
	Plate,
	PlateContent,
	type PlateEditor,
	PlateElement,
	type PlateElementProps,
	useEditorRef,
	useEditorSelector,
	usePlateEditor,
} from "platejs/react";
import { type MouseEvent, useCallback, useRef } from "react";

type PageEditorProps = {
	pageId: string;
	initialValue: Value;
	onChange: (value: Value) => void;
	readOnly?: boolean;
	disabled?: boolean;
};

const BLOCK_BUTTONS = [
	{ type: "p", label: "段落" },
	{ type: "h1", label: "見出し1" },
	{ type: "h2", label: "見出し2" },
] as const;

type BlockType = (typeof BLOCK_BUTTONS)[number]["type"];

const MARK_BUTTONS = [
	{ type: "bold", label: "太字" },
	{ type: "italic", label: "斜体" },
] as const;

type MarkType = (typeof MARK_BUTTONS)[number]["type"];

type MarkEditor = PlateEditor & {
	tf: PlateEditor["tf"] & Record<MarkType, { toggle: () => void }>;
};

export function PageEditor({
	pageId,
	initialValue,
	onChange,
	readOnly = false,
	disabled = false,
}: PageEditorProps) {
	assertPageEditorValue(initialValue);
	return (
		<PageEditorSession
			key={pageId}
			pageId={pageId}
			initialValue={initialValue}
			onChange={onChange}
			readOnly={readOnly}
			disabled={disabled}
		/>
	);
}

function PageEditorSession({
	pageId,
	initialValue,
	onChange,
	readOnly = false,
	disabled = false,
}: PageEditorProps) {
	const onChangeRef = useRef(onChange);
	onChangeRef.current = onChange;
	const readOnlyRef = useRef(readOnly);
	readOnlyRef.current = readOnly;
	const editor = usePlateEditor({
		id: pageId,
		plugins: [
			ParagraphPlugin.withComponent(ParagraphElement),
			BoldPlugin,
			ItalicPlugin,
			H1Plugin.withComponent(H1Element),
			H2Plugin.withComponent(H2Element),
		],
		value: initialValue,
	});
	const handleValueChange = useCallback(({ value }: { value: Value }) => {
		if (readOnlyRef.current) return;
		onChangeRef.current(structuredClone(value));
	}, []);

	return (
		<Plate editor={editor} onValueChange={handleValueChange}>
			<div className="page-editor">
				<PageEditorToolbar readOnly={readOnly || disabled} />
				<PlateContent
					aria-label="本文"
					className="page-editor-content"
					readOnly={readOnly || disabled}
				/>
			</div>
		</Plate>
	);
}

function PageEditorToolbar({ readOnly }: { readOnly: boolean }) {
	const editor = useEditorRef() as MarkEditor;
	const blockType = useEditorSelector(currentBlockType, []);
	const bold = useEditorSelector(
		(current) => current.api.marks()?.bold === true,
		[],
	);
	const italic = useEditorSelector(
		(current) => current.api.marks()?.italic === true,
		[],
	);
	const pressedMark = { bold, italic };

	return (
		<div aria-label="書式" className="page-editor-toolbar" role="toolbar">
			{BLOCK_BUTTONS.map((button) => (
				<button
					aria-pressed={blockType === button.type}
					disabled={readOnly}
					key={button.type}
					onClick={() => applyBlockType(editor, button.type)}
					onMouseDown={keepEditorFocus}
					type="button"
				>
					{button.label}
				</button>
			))}
			{MARK_BUTTONS.map((button) => (
				<button
					aria-pressed={pressedMark[button.type]}
					disabled={readOnly}
					key={button.type}
					onClick={() => applyMark(editor, button.type)}
					onMouseDown={keepEditorFocus}
					type="button"
				>
					{button.label}
				</button>
			))}
		</div>
	);
}

function ParagraphElement(props: PlateElementProps) {
	return <PlateElement {...props} as="p" />;
}

function H1Element(props: PlateElementProps) {
	return <PlateElement {...props} as="h1" />;
}

function H2Element(props: PlateElementProps) {
	return <PlateElement {...props} as="h2" />;
}

function currentBlockType(editor: PlateEditor): BlockType | "" {
	const type = editor.api.block()?.[0]?.type;
	if (type === "h1" || type === "h2" || type === "p") return type;
	return "";
}

function applyBlockType(editor: PlateEditor, type: BlockType) {
	if (!editor.selection) return;
	editor.tf.setNodes({ type });
	editor.tf.focus();
}

function applyMark(editor: MarkEditor, type: MarkType) {
	if (!editor.selection) return;
	editor.tf[type].toggle();
	editor.tf.focus();
}

function keepEditorFocus(event: MouseEvent<HTMLButtonElement>) {
	event.preventDefault();
}

function assertPageEditorValue(value: unknown): asserts value is Value {
	if (!Array.isArray(value)) {
		throw new Error("PageEditor initialValue must be an array");
	}
	if (value.length === 0) {
		throw new Error("PageEditor initialValue must not be empty");
	}
	for (const node of value) assertElementNode(node);
}

function assertElementNode(node: unknown): void {
	if (
		!isRecord(node) ||
		!Array.isArray(node.children) ||
		node.children.length === 0
	) {
		throw new Error("PageEditor initialValue contains a node without children");
	}
	for (const child of node.children) {
		if (isTextLeaf(child)) continue;
		assertElementNode(child);
	}
}

function isTextLeaf(node: unknown): boolean {
	return isRecord(node) && typeof node.text === "string";
}

function isRecord(value: unknown): value is Record<string, unknown> {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
